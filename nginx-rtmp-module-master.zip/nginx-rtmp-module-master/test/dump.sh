rtmpdump -v -r "rtmp://localhost/myapp/mystream"
